package com.rainiersoft.ioclparadip.ftg;

public interface IEventStatusChangedListener
{
   void StatusChanged();

}
